import Footer from "@/app/components/footer"
import Header from "@/app/components/header/header"

export default function AuthorPage(){
    return (
        <div>
            <Header/>
            <main>
                author page
            </main>

            <Footer/>
        </div>
    )
}